## Unreleased

### Visual resource format
- Standardized visual definitions on the explicit `animations` format.
- Removed support for the old visual `states` format and automatic numbered-frame discovery.
- Require every animation frame and property variant to list its Minecraft model identifiers.
- Delegate model parents, geometry, and texture inheritance to Minecraft.

# Changelog

## Alpha 1

Initial development milestone.

### Core
- State-based visual transitions
- Configurable durations in Minecraft ticks
- Variable animation frame counts
- Reusable block-family registration helpers
- Property-stage transitions

### Systems
- Repeater
- Furnace heating/cooling
- Redstone Dust timing
- Crops
- Doors
- Trapdoors
- Buttons
- Saplings
- Lever
- Redstone Torch
- Bamboo multi-property state handling

### Documentation
- Block registration guide
- Animation format guide
- State system overview
- Example pack documentation
